<template>
  <div class="buttons">
    <button id="previous" v-on:click="previous">Previous</button>
    <button id="next" v-on:click="next">Next</button>
  </div>
  <DayPilotScheduler :config="config" ref="schedulerRef" />
</template>

<script setup>
import { DayPilot, DayPilotScheduler } from 'daypilot-pro-vue';
import { ref, reactive, onMounted } from 'vue';

const config = reactive({
  timeHeaders: [{"groupBy":"Month"},{"groupBy":"Day","format":"d"}],
  scale: "Day",
  days: DayPilot.Date.today().daysInMonth(),
  startDate: DayPilot.Date.today().firstDayOfMonth(),
  timeRangeSelectedHandling: "Enabled",
  durationBarVisible: false,
  onTimeRangeSelected: async (args) => {
    const scheduler = args.control;
    const modal = await DayPilot.Modal.prompt("Create a new event:", "Event 1");
    scheduler.clearSelection();
    if (modal.canceled) { return; }
    scheduler.events.add({
      start: args.start,
      end: args.end,
      id: DayPilot.guid(),
      resource: args.resource,
      text: modal.result
    });
  },
  onBeforeEventRender: args => {
    args.data.areas = [
      {
        top: 8,
        right: 5,
        width: 20,
        height: 20,
        padding: 2,
        symbol: "icons/daypilot.svg#x-2",
        style: "cursor: pointer",
        fontColor: "#666",
        toolTip: "Delete",
        onClick: async args => {
          const e = args.source;
          schedulerRef.value?.control.events.remove(e);
        }
      }
    ];
  },
  treeEnabled: true,
});
const schedulerRef = ref(null);

const previous = () => {
  config.startDate = config.startDate.addMonths(-1);
  config.days = config.startDate.daysInMonth();
};

const next = () => {
  config.startDate = config.startDate.addMonths(1);
  config.days = config.startDate.daysInMonth();
};

const loadEvents = () => {
  const events = [
    {
      id: 1,
      start: DayPilot.Date.today().firstDayOfMonth().addDays(5),
      end: DayPilot.Date.today().firstDayOfMonth().addDays(10),
      text: "Event 1",
      resource: "R3",
      backColor: "#b2e0c9",
      borderColor: "#8cc9a6",
      fontColor: "#333"
    }
  ];
  config.events = events;
};

const loadResources = () => {
  const resources = [
    { name: "Resource 1", id: "R1" },
    { name: "Resource 2", id: "R2" },
    { name: "Resource 3", id: "R3" },
    { name: "Resource 4", id: "R4" },
    { name: "Resource 5", id: "R5" },
    { name: "Resource 6", id: "R6" },
    { name: "Resource 7", id: "R7" },
    { name: "Resource 8", id: "R8" },
    { name: "Resource 9", id: "R9" },
  ];
  config.resources = resources;
};

onMounted(() => {
  loadResources();
  loadEvents();
  schedulerRef.value?.control.message("Welcome!");
});
</script>

<style>
.scheduler_default_event,
.scheduler_default_event_inner {
  border-radius: 20px;
}

body .scheduler_default_event_inner {
  padding-left: 10px;
}
</style>

<style scoped>
.buttons {
  margin-bottom: 10px;
  display: inline-flex;
}

.buttons button {
  background-color: #3c78d8;
  color: white;
  border: 0;
  padding: .5rem 1rem;
  width: 80px;
  cursor: pointer;
  margin-right: 1px;
  transition: all 0.2s;
  box-shadow: 0 4px 6px rgba(0,0,0,0.08);
  box-sizing: border-box;
}

.buttons button:last-child {
  margin-right: 0;
}

.buttons button.selected {
  background-color: #1c4587;
  box-shadow: 0 3px 5px rgba(0,0,0,0.1);
}

.buttons button:first-child {
  border-top-left-radius: 30px;
  border-bottom-left-radius: 30px;
}

.buttons button:last-child {
  border-top-right-radius: 30px;
  border-bottom-right-radius: 30px;
}

.buttons button:hover {
  background-color: #2f66c4;
  box-shadow: 0 5px 7px rgba(0,0,0,0.1);
}

.buttons button:active {
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}
</style>
