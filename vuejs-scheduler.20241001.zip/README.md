# DayPilot UI Builder Template Project

This is a template project generated using [DayPilot UI Builder](https://builder.daypilot.org/).

## Project setup
```
npm install
```

### Compile and hot-reload for development
```
npm run dev
```

### Compile and minify for production
```
npm run build
```