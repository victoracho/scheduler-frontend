<template>
  <DayPilotScheduler :config="config" ref="schedulerRef" />
</template>

<script setup>
import { DayPilot, DayPilotScheduler } from 'daypilot-pro-vue';
import { ref, reactive, onMounted } from 'vue';

const config = reactive({
      timeHeaders: [{groupBy: "Month"}, {groupBy: "Day", format: "d"}],
      scale: "Day",
      days: DayPilot.Date.today().daysInYear(),
      startDate: DayPilot.Date.today().firstDayOfYear(),
      timeRangeSelectedHandling: "Enabled",
      eventHeight: 40,
      durationBarVisible: false,
      eventBorderRadius: 20,
      rowMarginTop: 2,
      rowMarginBottom: 2,
      rowHeaderColumns: [
        {title: "Name", display: "name"},
        {title: "Location", display: "location"},
        {title: "Status", width: 50}
      ],
      onTimeRangeSelected: async args => {
        const scheduler = schedulerRef.value?.control;
        const modal = await DayPilot.Modal.prompt("Create a new event:", "Event 1");
        scheduler.clearSelection();
        if (modal.canceled) {
          return;
        }
        scheduler.events.add({
          start: args.start,
          end: args.end,
          id: DayPilot.guid(),
          resource: args.resource,
          text: modal.result
        });
      },
      eventMoveHandling: "Update",
      onEventMoved: args => {
        args.control.message("Event moved: " + args.e.data.text);
      },
      eventResizeHandling: "Update",
      onEventResized: args => {
        args.control.message("Event resized: " + args.e.data.text);
      },
      eventClickHandling: "Enabled",
      onEventClicked: args => {
        args.control.message("Event clicked: " + args.e.data.text);
      },
      eventHoverHandling: "Disabled",
      treeEnabled: true,
      onBeforeRowHeaderRender: args => {
        if (args.row.data.status === "locked") {
          args.row.columns[2].areas = [
            {
              top: "calc(50% - 10px)",
              left: "calc(50% - 10px)",
              width: 20,
              height: 20,
              symbol: "icons/daypilot.svg#padlock",
              fontColor: "#999999",
              visibility: "Visible",
            }
          ];
        }
      },
      onBeforeEventRender: args => {
        args.data.backColor = args.data.color;
        args.data.borderColor = "darker";
        args.data.fontColor = "#ffffff";
        args.data.areas = [
          {
            top: 10,
            right: 6,
            width: 20,
            height: 20,
            symbol: "icons/daypilot.svg#minichevron-down-4",
            fontColor: "#999999",
            backColor: "#f9f9f9",
            borderRadius: "50%",
            visibility: "Visible",
            action: "ContextMenu",
            padding: 1,
            style: "border: 2px solid #ccc; cursor:pointer;"
          }
        ];
      },
      contextMenu: new DayPilot.Menu({
        items: [
          {
            text: "Delete",
            onClick: args => {
              const e = args.source;
              const scheduler = schedulerRef.value?.control;
              scheduler.events.remove(e);
              scheduler.message("Deleted.");
            }
          },
          {
            text: "-"
          },
          {
            text: "Blue",
            icon: "icon icon-blue",
            color: "#6fa8dc",
            onClick: args => {
              updateColor(args.source, args.item.color);
            }
          },
          {
            text: "Green",
            icon: "icon icon-green",
            color: "#93c47d",
            onClick: args => {
              updateColor(args.source, args.item.color);
            }
          },
          {
            text: "Yellow",
            icon: "icon icon-yellow",
            color: "#f1c232",
            onClick: args => {
              updateColor(args.source, args.item.color);
            }
          },
          {
            text: "Red",
            icon: "icon icon-red",
            color: "#dd7e6b",
            onClick: args => {
              updateColor(args.source, args.item.color);
            }
          },
        ]
      })
    }
);
const schedulerRef = ref(null);

const loadReservations = () => {
  const events = [
    {
      id: 1,
      resource: "R1",
      start: DayPilot.Date.today().firstDayOfMonth().addDays(3),
      end: DayPilot.Date.today().firstDayOfMonth().addDays(7),
      text: "Event 1",
      color: "#6fa8dc"
    },
    {
      id: 2,
      resource: "R1",
      start: DayPilot.Date.today().firstDayOfMonth().addDays(9),
      end: DayPilot.Date.today().firstDayOfMonth().addDays(12),
      text: "Event 2",
      color: "#93c47d"
    },
    {
      id: 3,
      resource: "R3",
      start: DayPilot.Date.today().firstDayOfMonth().addDays(3),
      end: DayPilot.Date.today().firstDayOfMonth().addDays(6),
      text: "Event 3",
      color: "#6fa8dc"
    },
    {
      id: 4,
      resource: "R2",
      start: DayPilot.Date.today().firstDayOfMonth().addDays(3),
      end: DayPilot.Date.today().firstDayOfMonth().addDays(6),
      text: "Event 4",
      color: "#93c47d"
    },
    {
      id: 5,
      resource: "R3",
      start: DayPilot.Date.today().firstDayOfMonth().addDays(7),
      end: DayPilot.Date.today().firstDayOfMonth().addDays(10),
      text: "Event 5",
      color: "#f1c232"
    },
    {
      id: 6,
      resource: "R3",
      start: DayPilot.Date.today().firstDayOfMonth().addDays(12),
      end: DayPilot.Date.today().firstDayOfMonth().addDays(15),
      text: "Event 6",
      color: "#dd7e6b"
    },
  ];

  config.events = events;
};

const loadResources = () => {
  const resources = [
    {
      name: "Group A", id: "GA", expanded: true, children: [
        {name: "Resource 1", id: "R1", location: "Location 1"},
        {name: "Resource 2", id: "R2", location: "Location 1"},
        {name: "Resource 3", id: "R3", location: "Location 2"},
        {name: "Resource 4", id: "R4", location: "Location 2", status: "locked"},
      ]
    },
    {
      name: "Group B", id: "GB", expanded: true, children: [
        {name: "Resource 5", id: "R5", location: "Location 3"},
        {name: "Resource 6", id: "R6", location: "Location 3"},
        {name: "Resource 7", id: "R7", location: "Location 4"},
        {name: "Resource 8", id: "R8", location: "Location 4"},
      ]
    }
  ];
  config.resources = resources;
};

const updateColor = (e, color) => {
  const scheduler = schedulerRef.value?.control;
  e.data.color = color;
  scheduler.events.update(e);
  scheduler.message("Color updated");
};

onMounted(() => {
  const scheduler = schedulerRef.value?.control;

  loadResources();
  loadReservations();

  scheduler.message("Welcome!");
  scheduler.scrollTo(DayPilot.Date.today().firstDayOfMonth());
});

</script>
