<template>
  <Scheduler />
</template>

<script setup>
import Scheduler from './components/Scheduler.vue'
</script>
